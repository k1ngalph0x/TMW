import 'package:flutter/material.dart';

class _BottomModalSheeState extends StatefulWidget {
  const _BottomModalSheeState({super.key});

  @override
  State<_BottomModalSheeState> createState() => __BottomModalSheeStateState();
}

class __BottomModalSheeStateState extends State<_BottomModalSheeState> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
